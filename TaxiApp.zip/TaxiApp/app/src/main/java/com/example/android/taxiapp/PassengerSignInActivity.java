package com.example.android.taxiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PassengerSignInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_sign_in);
    }
}